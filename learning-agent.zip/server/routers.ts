import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { goalsRouter } from "./routers/goals";
import { nudgesRouter } from "./routers/nudges";
import { quizzesRouter } from "./routers/quizzes";
import { tasksRouter } from "./routers/tasks";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  goals: goalsRouter,
  tasks: tasksRouter,
  quizzes: quizzesRouter,
  nudges: nudgesRouter,
});

export type AppRouter = typeof appRouter;
