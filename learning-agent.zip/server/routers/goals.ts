import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { invokeLLM } from "../_core/llm";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createGoal,
  createMilestone,
  createNudge,
  createTask,
  getDashboardStats,
  getGoalById,
  getGoalsByUser,
  getMilestonesByGoal,
  getTasksByGoal,
  getTasksByMilestone,
  updateGoalStatus,
  updateMilestoneStatus,
} from "../db";

// ─── AI Helpers ───────────────────────────────────────────────────────────────

async function parseGoalWithAI(rawGoal: string) {
  const res = await invokeLLM({
    model: "gpt-5-mini",
    messages: [
      {
        role: "system",
        content:
          "You are an expert learning coach. Parse the user's learning goal into structured fields. Return ONLY valid JSON.",
      },
      {
        role: "user",
        content: `Parse this learning goal: "${rawGoal}"\n\nReturn JSON with these fields:\n- domain: string (e.g. "Cloud Computing", "Data Science", "Web Development")\n- skillLevel: "beginner" | "intermediate" | "advanced"\n- targetOutcome: string (clear, measurable outcome)\n- timelineWeeks: number (realistic weeks to achieve goal, 4-24)\n- reasoning: string (brief explanation of your assessment)`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "goal_parse",
        strict: true,
        schema: {
          type: "object",
          properties: {
            domain: { type: "string" },
            skillLevel: { type: "string", enum: ["beginner", "intermediate", "advanced"] },
            targetOutcome: { type: "string" },
            timelineWeeks: { type: "number" },
            reasoning: { type: "string" },
          },
          required: ["domain", "skillLevel", "targetOutcome", "timelineWeeks", "reasoning"],
          additionalProperties: false,
        },
      },
    },
  });
  return JSON.parse(res.choices[0].message.content as string) as {
    domain: string;
    skillLevel: "beginner" | "intermediate" | "advanced";
    targetOutcome: string;
    timelineWeeks: number;
    reasoning: string;
  };
}

async function generateLearningPlanWithAI(goal: {
  rawGoal: string;
  domain: string;
  skillLevel: string;
  targetOutcome: string;
  timelineWeeks: number;
}) {
  const res = await invokeLLM({
    model: "gpt-5-mini",
    messages: [
      {
        role: "system",
        content:
          "You are an expert curriculum designer. Generate a detailed, week-by-week learning plan. Return ONLY valid JSON.",
      },
      {
        role: "user",
        content: `Create a ${goal.timelineWeeks}-week learning plan for:\nGoal: ${goal.rawGoal}\nDomain: ${goal.domain}\nSkill Level: ${goal.skillLevel}\nTarget Outcome: ${goal.targetOutcome}\n\nReturn a JSON object with a "milestones" array. Each milestone has:\n- weekNumber: number\n- title: string (e.g. "Week 1: Foundations of AWS")\n- description: string\n- tasks: array of objects with:\n  - title: string\n  - description: string\n  - type: "video" | "article" | "practice" | "quiz" | "project"\n  - estimatedMinutes: number`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "learning_plan",
        strict: true,
        schema: {
          type: "object",
          properties: {
            milestones: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  weekNumber: { type: "number" },
                  title: { type: "string" },
                  description: { type: "string" },
                  tasks: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        description: { type: "string" },
                        type: {
                          type: "string",
                          enum: ["video", "article", "practice", "quiz", "project"],
                        },
                        estimatedMinutes: { type: "number" },
                      },
                      required: ["title", "description", "type", "estimatedMinutes"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["weekNumber", "title", "description", "tasks"],
                additionalProperties: false,
              },
            },
          },
          required: ["milestones"],
          additionalProperties: false,
        },
      },
    },
  });
  return JSON.parse(res.choices[0].message.content as string) as {
    milestones: Array<{
      weekNumber: number;
      title: string;
      description: string;
      tasks: Array<{
        title: string;
        description: string;
        type: "video" | "article" | "practice" | "quiz" | "project";
        estimatedMinutes: number;
      }>;
    }>;
  };
}

// ─── Router ───────────────────────────────────────────────────────────────────

export const goalsRouter = router({
  parseGoal: protectedProcedure
    .input(z.object({ rawGoal: z.string().min(5) }))
    .mutation(async ({ input }) => {
      const parsed = await parseGoalWithAI(input.rawGoal);
      return parsed;
    }),

  create: protectedProcedure
    .input(
      z.object({
        rawGoal: z.string().min(5),
        domain: z.string(),
        skillLevel: z.enum(["beginner", "intermediate", "advanced"]),
        targetOutcome: z.string(),
        timelineWeeks: z.number().min(1).max(52),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const goalResult = await createGoal({
        userId: ctx.user.id,
        rawGoal: input.rawGoal,
        domain: input.domain,
        skillLevel: input.skillLevel,
        targetOutcome: input.targetOutcome,
        timelineWeeks: input.timelineWeeks,
      });
      const goalId = goalResult.id;

      // Generate learning plan
      const plan = await generateLearningPlanWithAI({
        rawGoal: input.rawGoal,
        domain: input.domain,
        skillLevel: input.skillLevel,
        targetOutcome: input.targetOutcome,
        timelineWeeks: input.timelineWeeks,
      });

      const now = new Date();
      for (const ms of plan.milestones) {
        const startDate = new Date(now);
        startDate.setDate(startDate.getDate() + (ms.weekNumber - 1) * 7);
        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + 6);

        const msResult = await createMilestone({
          goalId,
          weekNumber: ms.weekNumber,
          title: ms.title,
          description: ms.description,
          startDate,
          endDate,
        });

        for (const task of ms.tasks) {
          const dueDate = new Date(endDate);
          await createTask({
            milestoneId: msResult.id,
            goalId,
            title: task.title,
            description: task.description,
            type: task.type,
            estimatedMinutes: task.estimatedMinutes,
            dueDate,
          });
        }
      }

      // Welcome nudge
      await createNudge({
        userId: ctx.user.id,
        goalId,
        type: "encouragement",
        message: `Your personalized learning plan for "${input.rawGoal}" is ready! You have ${input.timelineWeeks} weeks to achieve your goal. Let's get started — your first milestone awaits!`,
      });

      return { goalId };
    }),

  list: protectedProcedure.query(async ({ ctx }) => {
    return getGoalsByUser(ctx.user.id);
  }),

  get: protectedProcedure
    .input(z.object({ goalId: z.number() }))
    .query(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) {
        throw new TRPCError({ code: "NOT_FOUND" });
      }
      const ms = await getMilestonesByGoal(input.goalId);
      const milestonesWithTasks = await Promise.all(
        ms.map(async (m) => ({
          ...m,
          tasks: await getTasksByMilestone(m.id),
        }))
      );
      return { goal, milestones: milestonesWithTasks };
    }),

  updateStatus: protectedProcedure
    .input(z.object({ goalId: z.number(), status: z.enum(["active", "completed", "paused"]) }))
    .mutation(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      await updateGoalStatus(input.goalId, input.status);
      return { success: true };
    }),

  adaptPlan: protectedProcedure
    .input(
      z.object({
        goalId: z.number(),
        milestoneId: z.number(),
        reason: z.enum(["behind", "ahead", "quiz_failed"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });

      const allTasks = await getTasksByGoal(input.goalId);
      const milestoneTasks = allTasks.filter((t) => t.milestoneId === input.milestoneId);
      const completedCount = milestoneTasks.filter((t) => t.status === "completed").length;

      const res = await invokeLLM({
        model: "gpt-5-mini",
        messages: [
          {
            role: "system",
            content:
              "You are a learning coach adapting a student's plan. Return ONLY valid JSON.",
          },
          {
            role: "user",
            content: `A learner working on "${goal.rawGoal}" (${goal.domain}, ${goal.skillLevel}) has ${input.reason === "behind" ? "fallen behind" : input.reason === "ahead" ? "progressed faster than expected" : "failed a quiz"}. They completed ${completedCount}/${milestoneTasks.length} tasks in this milestone.\n\nGenerate 2-3 remedial/adjustment tasks to add to their plan. Return JSON with a "tasks" array where each task has: title, description, type ("video"|"article"|"practice"|"remedial"), estimatedMinutes.`,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "adapt_plan",
            strict: true,
            schema: {
              type: "object",
              properties: {
                tasks: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      description: { type: "string" },
                      type: {
                        type: "string",
                        enum: ["video", "article", "practice", "remedial"],
                      },
                      estimatedMinutes: { type: "number" },
                    },
                    required: ["title", "description", "type", "estimatedMinutes"],
                    additionalProperties: false,
                  },
                },
                message: { type: "string" },
              },
              required: ["tasks", "message"],
              additionalProperties: false,
            },
          },
        },
      });

      const adapted = JSON.parse(res.choices[0].message.content as string) as {
        tasks: Array<{
          title: string;
          description: string;
          type: "video" | "article" | "practice" | "remedial";
          estimatedMinutes: number;
        }>;
        message: string;
      };

      for (const task of adapted.tasks) {
        await createTask({
          milestoneId: input.milestoneId,
          goalId: input.goalId,
          title: task.title,
          description: task.description,
          type: task.type,
          estimatedMinutes: task.estimatedMinutes,
          isRemedial: true,
        });
      }

      if (input.reason === "behind" || input.reason === "quiz_failed") {
        await updateMilestoneStatus(input.milestoneId, "delayed");
      }

      return { addedTasks: adapted.tasks.length, message: adapted.message };
    }),

  dashboard: protectedProcedure
    .input(z.object({ goalId: z.number() }))
    .query(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      const stats = await getDashboardStats(ctx.user.id, input.goalId);
      return stats;
    }),
});
