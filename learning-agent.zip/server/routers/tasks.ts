import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  completeTask,
  getActivityLog,
  getGoalById,
  getTasksByGoal,
  uncompleteTask,
  upsertActivityLog,
} from "../db";

export const tasksRouter = router({
  list: protectedProcedure
    .input(z.object({ goalId: z.number() }))
    .query(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      return getTasksByGoal(input.goalId);
    }),

  complete: protectedProcedure
    .input(
      z.object({
        taskId: z.number(),
        goalId: z.number(),
        actualMinutes: z.number().min(0).default(0),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      await completeTask(input.taskId, input.actualMinutes);

      // Log activity
      const today = new Date().toISOString().slice(0, 10);
      const logs = await getActivityLog(ctx.user.id, input.goalId, 1);
      const existing = logs.find((l) => l.date === today);
      await upsertActivityLog({
        userId: ctx.user.id,
        goalId: input.goalId,
        date: today,
        minutesSpent: (existing?.minutesSpent ?? 0) + input.actualMinutes,
      });

      return { success: true };
    }),

  uncomplete: protectedProcedure
    .input(z.object({ taskId: z.number(), goalId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      await uncompleteTask(input.taskId);
      return { success: true };
    }),

  activityLog: protectedProcedure
    .input(z.object({ goalId: z.number(), days: z.number().default(14) }))
    .query(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      return getActivityLog(ctx.user.id, input.goalId, input.days);
    }),
});
