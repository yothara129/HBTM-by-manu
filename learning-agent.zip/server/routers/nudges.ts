import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { invokeLLM } from "../_core/llm";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createNudge,
  getGoalsByUser,
  getLastActivityDate,
  getNudgesByUser,
  markAllNudgesRead,
  markNudgeRead,
} from "../db";

export const nudgesRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return getNudgesByUser(ctx.user.id);
  }),

  markRead: protectedProcedure
    .input(z.object({ nudgeId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const allNudges = await getNudgesByUser(ctx.user.id);
      const nudge = allNudges.find((n) => n.id === input.nudgeId);
      if (!nudge) throw new TRPCError({ code: "NOT_FOUND" });
      await markNudgeRead(input.nudgeId);
      return { success: true };
    }),

  markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
    await markAllNudgesRead(ctx.user.id);
    return { success: true };
  }),

  checkAndGenerate: protectedProcedure.mutation(async ({ ctx }) => {
    const goals = await getGoalsByUser(ctx.user.id);
    const activeGoals = goals.filter((g) => g.status === "active");
    if (activeGoals.length === 0) return { generated: 0 };

    const lastActivity = await getLastActivityDate(ctx.user.id);
    let generated = 0;

    // Determine days since last activity (or since goal creation if no activity)
    let diffDays = 0;
    if (lastActivity) {
      const lastDate = new Date(lastActivity);
      const today = new Date();
      diffDays = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
    } else {
      // No activity at all — use oldest goal creation date
      const oldest = activeGoals.reduce((a, b) =>
        new Date(a.createdAt) < new Date(b.createdAt) ? a : b
      );
      const today = new Date();
      diffDays = Math.floor((today.getTime() - new Date(oldest.createdAt).getTime()) / (1000 * 60 * 60 * 24));
    }

    if (diffDays >= 3) {
      // Generate nudge for each active goal (up to 3)
      for (const goal of activeGoals.slice(0, 3)) {
        const nudgeRes = await invokeLLM({
          model: "gpt-5-mini",
          messages: [
            {
              role: "system",
              content: "You are a supportive learning coach. Write a brief, personalized nudge message.",
            },
            {
              role: "user",
              content: `A learner working on "${goal.rawGoal}" (${goal.domain}, ${goal.skillLevel} level) has been inactive for ${diffDays} days. Write a short (2-3 sentence) context-aware nudge that references their specific goal and suggests a concrete next step to get back on track. Be warm and encouraging.`,
            },
          ],
        });
        await createNudge({
          userId: ctx.user.id,
          goalId: goal.id,
          type: "inactivity",
          message: nudgeRes.choices[0].message.content as string,
        });
        generated++;
      }
    }

    return { generated };
  }),
});
