import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { invokeLLM } from "../_core/llm";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createNudge,
  createQuizAttempt,
  getGoalById,
  getMilestonesByGoal,
  getQuizAttemptsByMilestone,
  markFeedbackApplied,
} from "../db";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

async function generateQuizQuestions(
  milestoneTitle: string,
  milestoneDescription: string,
  domain: string
): Promise<QuizQuestion[]> {
  const res = await invokeLLM({
    model: "gpt-5-mini",
    messages: [
      {
        role: "system",
        content:
          "You are an expert quiz creator. Generate multiple-choice quiz questions. Return ONLY valid JSON.",
      },
      {
        role: "user",
        content: `Create 5 multiple-choice questions for this learning milestone:\nTitle: ${milestoneTitle}\nDescription: ${milestoneDescription}\nDomain: ${domain}\n\nReturn JSON with a "questions" array. Each question has: id (1-5), question (string), options (array of 4 strings), correctIndex (0-3), explanation (string).`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "quiz",
        strict: true,
        schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  id: { type: "number" },
                  question: { type: "string" },
                  options: { type: "array", items: { type: "string" } },
                  correctIndex: { type: "number" },
                  explanation: { type: "string" },
                },
                required: ["id", "question", "options", "correctIndex", "explanation"],
                additionalProperties: false,
              },
            },
          },
          required: ["questions"],
          additionalProperties: false,
        },
      },
    },
  });
  const parsed = JSON.parse(res.choices[0].message.content as string) as {
    questions: QuizQuestion[];
  };
  return parsed.questions;
}

export const quizzesRouter = router({
  generate: protectedProcedure
    .input(z.object({ milestoneId: z.number(), goalId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });

      const ms = await getMilestonesByGoal(input.goalId);
      const milestone = ms.find((m) => m.id === input.milestoneId);
      if (!milestone) throw new TRPCError({ code: "NOT_FOUND" });

      const questions = await generateQuizQuestions(
        milestone.title,
        milestone.description ?? "",
        goal.domain ?? goal.rawGoal
      );

      return { questions };
    }),

  submit: protectedProcedure
    .input(
      z.object({
        milestoneId: z.number(),
        goalId: z.number(),
        questions: z.array(z.any()),
        answers: z.array(z.number()),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });

      const questions = input.questions as QuizQuestion[];
      let correct = 0;
      const results = questions.map((q, i) => {
        const isCorrect = input.answers[i] === q.correctIndex;
        if (isCorrect) correct++;
        return { questionId: q.id, selected: input.answers[i], correct: isCorrect, explanation: q.explanation };
      });

      const score = Math.round((correct / questions.length) * 100);
      const passed = score >= 70;

      const attempt = await createQuizAttempt({
        milestoneId: input.milestoneId,
        userId: ctx.user.id,
        goalId: input.goalId,
        questions,
        answers: input.answers,
        score,
        totalQuestions: questions.length,
        passed,
      });

      if (!passed) {
        // Generate contextual nudge for quiz failure
        const ms = await getMilestonesByGoal(input.goalId);
        const milestone = ms.find((m) => m.id === input.milestoneId);
        const nudgeRes = await invokeLLM({
          model: "gpt-5-mini",
          messages: [
            {
              role: "system",
              content: "You are a supportive learning coach. Write a brief, encouraging nudge message.",
            },
            {
              role: "user",
              content: `A learner working on "${goal.rawGoal}" scored ${score}% on the quiz for "${milestone?.title}". Write a short (2-3 sentence) context-aware nudge that references their specific goal and suggests a concrete next step. Be encouraging, not discouraging.`,
            },
          ],
        });

        await createNudge({
          userId: ctx.user.id,
          goalId: input.goalId,
          type: "quiz_failure",
          message: nudgeRes.choices[0].message.content as string,
        });
      }

      return { score, passed, results, attemptId: attempt.id };
    }),

  history: protectedProcedure
    .input(z.object({ milestoneId: z.number(), goalId: z.number() }))
    .query(async ({ ctx, input }) => {
      const goal = await getGoalById(input.goalId);
      if (!goal || goal.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      return getQuizAttemptsByMilestone(input.milestoneId);
    }),

  applyFeedback: protectedProcedure
    .input(z.object({ attemptId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Verify the attempt belongs to this user
      const attempts = await getQuizAttemptsByMilestone(0); // will be filtered below
      // Just check via userId on the attempt
      const { getDb } = await import("../db");
      const { quizAttempts } = await import("../../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");
      const db = await getDb();
      if (db) {
        const rows = await db.select().from(quizAttempts).where(and(eq(quizAttempts.id, input.attemptId), eq(quizAttempts.userId, ctx.user.id))).limit(1);
        if (rows.length === 0) throw new TRPCError({ code: "NOT_FOUND" });
      }
      await markFeedbackApplied(input.attemptId);
      return { success: true };
    }),
});
