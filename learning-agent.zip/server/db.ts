import { and, desc, eq, gte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  activityLog,
  learningGoals,
  milestones,
  nudges,
  quizAttempts,
  tasks,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ─── Goals ───────────────────────────────────────────────────────────────────

export async function createGoal(data: {
  userId: number;
  rawGoal: string;
  domain?: string;
  skillLevel?: "beginner" | "intermediate" | "advanced";
  targetOutcome?: string;
  timelineWeeks?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(learningGoals).values(data).$returningId();
  return result;
}

export async function getGoalsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(learningGoals)
    .where(eq(learningGoals.userId, userId))
    .orderBy(desc(learningGoals.createdAt));
}

export async function getGoalById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(learningGoals).where(eq(learningGoals.id, id)).limit(1);
  return result[0];
}

export async function updateGoalStatus(id: number, status: "active" | "completed" | "paused") {
  const db = await getDb();
  if (!db) return;
  await db.update(learningGoals).set({ status }).where(eq(learningGoals.id, id));
}

// ─── Milestones ───────────────────────────────────────────────────────────────

export async function createMilestone(data: {
  goalId: number;
  weekNumber: number;
  title: string;
  description?: string;
  startDate?: Date;
  endDate?: Date;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(milestones).values(data).$returningId();
  return result;
}

export async function getMilestonesByGoal(goalId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(milestones)
    .where(eq(milestones.goalId, goalId))
    .orderBy(milestones.weekNumber);
}

export async function updateMilestoneStatus(
  id: number,
  status: "pending" | "in_progress" | "completed" | "delayed"
) {
  const db = await getDb();
  if (!db) return;
  await db.update(milestones).set({ status }).where(eq(milestones.id, id));
}

// ─── Tasks ────────────────────────────────────────────────────────────────────

export async function createTask(data: {
  milestoneId: number;
  goalId: number;
  title: string;
  description?: string;
  type?: "video" | "article" | "practice" | "quiz" | "project" | "remedial";
  estimatedMinutes?: number;
  dueDate?: Date;
  isRemedial?: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(tasks).values(data).$returningId();
  return result;
}

export async function getTasksByMilestone(milestoneId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks).where(eq(tasks.milestoneId, milestoneId)).orderBy(tasks.createdAt);
}

export async function getTasksByGoal(goalId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks).where(eq(tasks.goalId, goalId)).orderBy(tasks.createdAt);
}

export async function completeTask(id: number, actualMinutes: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(tasks)
    .set({ status: "completed", actualMinutes, completedAt: new Date() })
    .where(eq(tasks.id, id));
}

export async function uncompleteTask(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(tasks)
    .set({ status: "pending", actualMinutes: 0, completedAt: null })
    .where(eq(tasks.id, id));
}

// ─── Quizzes ──────────────────────────────────────────────────────────────────

export async function createQuizAttempt(data: {
  milestoneId: number;
  userId: number;
  goalId: number;
  questions: unknown;
  answers?: unknown;
  score?: number;
  totalQuestions?: number;
  passed?: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(quizAttempts).values(data).$returningId();
  return result;
}

export async function getQuizAttemptsByMilestone(milestoneId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(quizAttempts)
    .where(eq(quizAttempts.milestoneId, milestoneId))
    .orderBy(desc(quizAttempts.createdAt));
}

export async function markFeedbackApplied(attemptId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(quizAttempts).set({ feedbackApplied: true }).where(eq(quizAttempts.id, attemptId));
}

// ─── Nudges ───────────────────────────────────────────────────────────────────

export async function createNudge(data: {
  userId: number;
  goalId: number;
  type: "inactivity" | "quiz_failure" | "milestone_complete" | "encouragement";
  message: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(nudges).values(data).$returningId();
  return result;
}

export async function getNudgesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(nudges)
    .where(eq(nudges.userId, userId))
    .orderBy(desc(nudges.createdAt))
    .limit(20);
}

export async function markNudgeRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(nudges).set({ isRead: true }).where(eq(nudges.id, id));
}

export async function markAllNudgesRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(nudges).set({ isRead: true }).where(eq(nudges.userId, userId));
}

// ─── Activity Log ─────────────────────────────────────────────────────────────

export async function upsertActivityLog(data: {
  userId: number;
  goalId: number;
  date: string;
  minutesSpent: number;
}) {
  const db = await getDb();
  if (!db) return;
  await db
    .insert(activityLog)
    .values(data)
    .onDuplicateKeyUpdate({ set: { minutesSpent: data.minutesSpent } });
}

export async function getActivityLog(userId: number, goalId: number, days = 30) {
  const db = await getDb();
  if (!db) return [];
  const since = new Date();
  since.setDate(since.getDate() - days);
  const sinceStr = since.toISOString().slice(0, 10);
  return db
    .select()
    .from(activityLog)
    .where(
      and(
        eq(activityLog.userId, userId),
        eq(activityLog.goalId, goalId),
        gte(activityLog.date, sinceStr)
      )
    )
    .orderBy(activityLog.date);
}

export async function getLastActivityDate(userId: number): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select({ date: activityLog.date })
    .from(activityLog)
    .where(eq(activityLog.userId, userId))
    .orderBy(desc(activityLog.date))
    .limit(1);
  return result[0]?.date ?? null;
}

// ─── Dashboard Stats ──────────────────────────────────────────────────────────

export async function getDashboardStats(userId: number, goalId: number) {
  const db = await getDb();
  if (!db) return null;

  const allTasks = await db
    .select()
    .from(tasks)
    .where(eq(tasks.goalId, goalId));

  const totalTasks = allTasks.length;
  const completedTasks = allTasks.filter((t) => t.status === "completed").length;
  const completionPct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const totalEstimated = allTasks.reduce((s, t) => s + (t.estimatedMinutes ?? 0), 0);
  const totalActual = allTasks.reduce((s, t) => s + (t.actualMinutes ?? 0), 0);

  // Upcoming tasks (not completed, ordered by dueDate)
  const upcoming = allTasks
    .filter((t) => t.status !== "completed")
    .sort((a, b) => {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    })
    .slice(0, 5);

  // Streak calculation
  const logs = await db
    .select({ date: activityLog.date })
    .from(activityLog)
    .where(and(eq(activityLog.userId, userId), eq(activityLog.goalId, goalId)))
    .orderBy(desc(activityLog.date));

  let streak = 0;
  const today = new Date().toISOString().slice(0, 10);
  let checkDate = today;
  const logDates = new Set(logs.map((l) => l.date));
  while (logDates.has(checkDate)) {
    streak++;
    const d = new Date(checkDate);
    d.setDate(d.getDate() - 1);
    checkDate = d.toISOString().slice(0, 10);
  }

  return {
    totalTasks,
    completedTasks,
    completionPct,
    totalEstimatedMinutes: totalEstimated,
    totalActualMinutes: totalActual,
    streak,
    upcomingTasks: upcoming,
  };
}
