import { describe, expect, it, vi, beforeEach } from "vitest";

// ─── Dashboard Stats Calculation Tests ───────────────────────────────────────

describe("Dashboard Stats Calculation", () => {
  it("calculates completion percentage correctly", () => {
    const totalTasks = 10;
    const completedTasks = 7;
    const completionPct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    expect(completionPct).toBe(70);
  });

  it("returns 0% when no tasks exist", () => {
    const totalTasks = 0;
    const completedTasks = 0;
    const completionPct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    expect(completionPct).toBe(0);
  });

  it("returns 100% when all tasks are completed", () => {
    const totalTasks = 5;
    const completedTasks = 5;
    const completionPct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    expect(completionPct).toBe(100);
  });

  it("calculates streak correctly for consecutive days", () => {
    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const dayBefore = new Date(Date.now() - 2 * 86400000).toISOString().slice(0, 10);

    const logDates = new Set([today, yesterday, dayBefore]);
    let streak = 0;
    let checkDate = today;
    while (logDates.has(checkDate)) {
      streak++;
      const d = new Date(checkDate);
      d.setDate(d.getDate() - 1);
      checkDate = d.toISOString().slice(0, 10);
    }
    expect(streak).toBe(3);
  });

  it("streak breaks on gap in activity", () => {
    const today = new Date().toISOString().slice(0, 10);
    const threeDaysAgo = new Date(Date.now() - 3 * 86400000).toISOString().slice(0, 10);

    const logDates = new Set([today, threeDaysAgo]);
    let streak = 0;
    let checkDate = today;
    while (logDates.has(checkDate)) {
      streak++;
      const d = new Date(checkDate);
      d.setDate(d.getDate() - 1);
      checkDate = d.toISOString().slice(0, 10);
    }
    expect(streak).toBe(1); // Only today counts
  });
});

// ─── Nudge Trigger Logic Tests ────────────────────────────────────────────────

describe("Nudge Trigger Logic", () => {
  it("triggers inactivity nudge after 3+ days of inactivity", () => {
    const lastActivity = new Date(Date.now() - 4 * 86400000).toISOString().slice(0, 10);
    const today = new Date();
    const lastDate = new Date(lastActivity);
    const diffDays = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
    expect(diffDays).toBeGreaterThanOrEqual(3);
  });

  it("does not trigger nudge if activity was yesterday", () => {
    const lastActivity = new Date(Date.now() - 1 * 86400000).toISOString().slice(0, 10);
    const today = new Date();
    const lastDate = new Date(lastActivity);
    const diffDays = Math.floor((today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
    expect(diffDays).toBeLessThan(3);
  });

  it("quiz failure triggers nudge when score < 70", () => {
    const score = 60;
    const passed = score >= 70;
    expect(passed).toBe(false);
    // Nudge should be generated
    const shouldNudge = !passed;
    expect(shouldNudge).toBe(true);
  });

  it("no nudge on passing quiz score", () => {
    const score = 80;
    const passed = score >= 70;
    expect(passed).toBe(true);
    const shouldNudge = !passed;
    expect(shouldNudge).toBe(false);
  });
});

// ─── Quiz Scoring Tests ───────────────────────────────────────────────────────

describe("Quiz Scoring", () => {
  const questions = [
    { id: 1, correctIndex: 0 },
    { id: 2, correctIndex: 2 },
    { id: 3, correctIndex: 1 },
    { id: 4, correctIndex: 3 },
    { id: 5, correctIndex: 0 },
  ];

  it("scores 100% when all answers are correct", () => {
    const answers = [0, 2, 1, 3, 0];
    let correct = 0;
    questions.forEach((q, i) => {
      if (answers[i] === q.correctIndex) correct++;
    });
    const score = Math.round((correct / questions.length) * 100);
    expect(score).toBe(100);
  });

  it("scores 60% when 3 of 5 are correct", () => {
    const answers = [0, 2, 1, 0, 1]; // 3 correct (0, 2, 1)
    let correct = 0;
    questions.forEach((q, i) => {
      if (answers[i] === q.correctIndex) correct++;
    });
    const score = Math.round((correct / questions.length) * 100);
    expect(score).toBe(60);
  });

  it("marks as failed when score < 70", () => {
    const score = 60;
    expect(score >= 70).toBe(false);
  });

  it("marks as passed when score >= 70", () => {
    const score = 80;
    expect(score >= 70).toBe(true);
  });
});

// ─── Goal Parsing Validation ──────────────────────────────────────────────────

describe("Goal Parsing Validation", () => {
  it("validates timeline is within bounds", () => {
    const timelineWeeks = 8;
    expect(timelineWeeks).toBeGreaterThanOrEqual(1);
    expect(timelineWeeks).toBeLessThanOrEqual(52);
  });

  it("validates skill level is one of the allowed values", () => {
    const allowed = ["beginner", "intermediate", "advanced"];
    const skillLevel = "intermediate";
    expect(allowed).toContain(skillLevel);
  });

  it("rejects empty goal string", () => {
    const rawGoal = "";
    expect(rawGoal.trim().length).toBeLessThan(5);
  });

  it("accepts valid goal string", () => {
    const rawGoal = "Pass the AWS Solutions Architect exam";
    expect(rawGoal.trim().length).toBeGreaterThanOrEqual(5);
  });
});
