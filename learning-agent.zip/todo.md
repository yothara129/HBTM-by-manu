# AI Personal Learning Agent — TODO

## Database & Schema
- [x] learning_goals table (id, userId, goal, domain, skillLevel, targetOutcome, timeline, status, createdAt)
- [x] milestones table (id, goalId, weekNumber, title, description, status, startDate, endDate)
- [x] tasks table (id, milestoneId, goalId, title, description, type, status, estimatedMinutes, actualMinutes, dueDate, completedAt, isRemedial)
- [x] quiz_attempts table (id, milestoneId, userId, goalId, score, totalQuestions, answers JSON, createdAt)
- [x] nudges table (id, userId, goalId, type, message, isRead, createdAt)
- [x] activity_log table (id, userId, goalId, date, minutesSpent)

## Backend (tRPC Routers)
- [x] goals.parseGoal — AI parses goal (domain, skillLevel, targetOutcome, timeline)
- [x] goals.create — creates goal + generates full learning plan with AI
- [x] goals.list — list user's goals
- [x] goals.get — get single goal with milestones and tasks
- [x] goals.updateStatus — update goal status
- [x] goals.adaptPlan — AI adapts plan (adds remedial tasks on quiz failure/behind)
- [x] goals.dashboard — stats: completion %, streak, time spent vs planned, upcoming tasks
- [x] tasks.list — list tasks for a goal
- [x] tasks.complete — mark task done, log time, update activity log
- [x] tasks.uncomplete — undo task completion
- [x] tasks.activityLog — get activity log for chart
- [x] quizzes.generate — AI generates 5 MCQ questions for a milestone
- [x] quizzes.submit — submit answers, score, trigger nudge if low score
- [x] quizzes.history — list quiz attempts for milestone
- [x] quizzes.applyFeedback — mark feedback as applied
- [x] nudges.list — list nudges for user
- [x] nudges.markRead — mark single nudge read
- [x] nudges.markAllRead — mark all nudges read
- [x] nudges.checkAndGenerate — check inactivity (3+ days) and create nudges

## Frontend Pages & Components
- [x] Landing page — hero, features grid, CTA
- [x] Goal intake form — multi-step wizard (input → AI parsing → confirm → generating)
- [x] Goals list page — cards with status badges, empty state
- [x] Dashboard page — stats cards, progress bar, activity chart, upcoming tasks, nudges panel
- [x] Learning plan page — expandable milestone list with task items
- [x] Task completion — click to complete, log time, undo
- [x] Quiz modal — generate, take, submit, see results, adapt plan
- [x] Nudges panel — bell icon, unread count, mark read, context-aware messages

## AI Features
- [x] LLM goal parsing (structured JSON: domain, skillLevel, targetOutcome, timelineWeeks, reasoning)
- [x] LLM learning plan generation (week-by-week milestones with tasks)
- [x] LLM quiz generation (5 MCQ questions per milestone)
- [x] LLM plan adaptation (add remedial tasks on low quiz score)
- [x] LLM smart nudge message generation (context-aware, goal-specific)

## Design & UX
- [x] Premium dark theme with violet accent
- [x] Google Fonts (Inter + Playfair Display)
- [x] Framer Motion animations throughout
- [x] Recharts for activity bar chart
- [x] Responsive layout (mobile + desktop)
- [x] Glass morphism cards
- [x] Gradient text and glow effects

## Tests
- [x] Vitest: dashboard stats calculation (completion %, streak)
- [x] Vitest: nudge trigger logic (inactivity, quiz failure)
- [x] Vitest: quiz scoring (correct/incorrect, pass/fail)
- [x] Vitest: goal parsing validation
- [x] Vitest: auth logout test (existing)
