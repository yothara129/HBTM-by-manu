import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  json,
  boolean,
  float,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

// Users
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Learning Goals
export const learningGoals = mysqlTable("learning_goals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  rawGoal: text("rawGoal").notNull(),
  domain: varchar("domain", { length: 256 }),
  skillLevel: mysqlEnum("skillLevel", ["beginner", "intermediate", "advanced"]).default("beginner"),
  targetOutcome: text("targetOutcome"),
  timelineWeeks: int("timelineWeeks").default(8),
  status: mysqlEnum("status", ["active", "completed", "paused"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LearningGoal = typeof learningGoals.$inferSelect;

// Milestones (weekly blocks)
export const milestones = mysqlTable("milestones", {
  id: int("id").autoincrement().primaryKey(),
  goalId: int("goalId").notNull(),
  weekNumber: int("weekNumber").notNull(),
  title: varchar("title", { length: 512 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "delayed"]).default("pending").notNull(),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Milestone = typeof milestones.$inferSelect;

// Tasks within milestones
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  milestoneId: int("milestoneId").notNull(),
  goalId: int("goalId").notNull(),
  title: varchar("title", { length: 512 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["video", "article", "practice", "quiz", "project", "remedial"]).default("article").notNull(),
  status: mysqlEnum("status", ["pending", "in_progress", "completed"]).default("pending").notNull(),
  estimatedMinutes: int("estimatedMinutes").default(30),
  actualMinutes: int("actualMinutes").default(0),
  dueDate: timestamp("dueDate"),
  completedAt: timestamp("completedAt"),
  isRemedial: boolean("isRemedial").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;

// Quiz Attempts
export const quizAttempts = mysqlTable("quiz_attempts", {
  id: int("id").autoincrement().primaryKey(),
  milestoneId: int("milestoneId").notNull(),
  userId: int("userId").notNull(),
  goalId: int("goalId").notNull(),
  questions: json("questions").notNull(),
  answers: json("answers"),
  score: float("score").default(0),
  totalQuestions: int("totalQuestions").default(5),
  passed: boolean("passed").default(false),
  feedbackApplied: boolean("feedbackApplied").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QuizAttempt = typeof quizAttempts.$inferSelect;

// Smart Nudges
export const nudges = mysqlTable("nudges", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  goalId: int("goalId").notNull(),
  type: mysqlEnum("type", ["inactivity", "quiz_failure", "milestone_complete", "encouragement"]).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Nudge = typeof nudges.$inferSelect;

// Activity Log (daily time tracking)
export const activityLog = mysqlTable("activity_log", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  goalId: int("goalId").notNull(),
  date: varchar("date", { length: 10 }).notNull(),
  minutesSpent: int("minutesSpent").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  uniqueUserGoalDate: uniqueIndex("activity_log_user_goal_date").on(table.userId, table.goalId, table.date),
}));

export type ActivityLog = typeof activityLog.$inferSelect;
