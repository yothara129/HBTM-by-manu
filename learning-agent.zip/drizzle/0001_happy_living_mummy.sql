CREATE TABLE `activity_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`goalId` int NOT NULL,
	`date` varchar(10) NOT NULL,
	`minutesSpent` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `learning_goals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`rawGoal` text NOT NULL,
	`domain` varchar(256),
	`skillLevel` enum('beginner','intermediate','advanced') DEFAULT 'beginner',
	`targetOutcome` text,
	`timelineWeeks` int DEFAULT 8,
	`status` enum('active','completed','paused') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `learning_goals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `milestones` (
	`id` int AUTO_INCREMENT NOT NULL,
	`goalId` int NOT NULL,
	`weekNumber` int NOT NULL,
	`title` varchar(512) NOT NULL,
	`description` text,
	`status` enum('pending','in_progress','completed','delayed') NOT NULL DEFAULT 'pending',
	`startDate` timestamp,
	`endDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `milestones_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `nudges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`goalId` int NOT NULL,
	`type` enum('inactivity','quiz_failure','milestone_complete','encouragement') NOT NULL,
	`message` text NOT NULL,
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `nudges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quiz_attempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`milestoneId` int NOT NULL,
	`userId` int NOT NULL,
	`goalId` int NOT NULL,
	`questions` json NOT NULL,
	`answers` json,
	`score` float DEFAULT 0,
	`totalQuestions` int DEFAULT 5,
	`passed` boolean DEFAULT false,
	`feedbackApplied` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quiz_attempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`milestoneId` int NOT NULL,
	`goalId` int NOT NULL,
	`title` varchar(512) NOT NULL,
	`description` text,
	`type` enum('video','article','practice','quiz','project','remedial') NOT NULL DEFAULT 'article',
	`status` enum('pending','in_progress','completed') NOT NULL DEFAULT 'pending',
	`estimatedMinutes` int DEFAULT 30,
	`actualMinutes` int DEFAULT 0,
	`dueDate` timestamp,
	`completedAt` timestamp,
	`isRemedial` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tasks_id` PRIMARY KEY(`id`)
);
