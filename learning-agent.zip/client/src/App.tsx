import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import GoalIntake from "./pages/GoalIntake";
import LearningPlan from "./pages/LearningPlan";
import Goals from "./pages/Goals";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/goals" component={Goals} />
      <Route path="/goals/new" component={GoalIntake} />
      <Route path="/goals/:goalId/dashboard" component={Dashboard} />
      <Route path="/goals/:goalId/plan" component={LearningPlan} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster richColors position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
