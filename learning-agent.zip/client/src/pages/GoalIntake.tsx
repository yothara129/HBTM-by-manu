import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { toast } from "sonner";
import {
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Brain,
  Target,
  Clock,
  BarChart,
  CheckCircle2,
  Loader2,
} from "lucide-react";

type ParsedGoal = {
  domain: string;
  skillLevel: "beginner" | "intermediate" | "advanced";
  targetOutcome: string;
  timelineWeeks: number;
  reasoning: string;
};

const skillColors = {
  beginner: "bg-green-500/10 text-green-400 border-green-500/20",
  intermediate: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  advanced: "bg-red-500/10 text-red-400 border-red-500/20",
};

const exampleGoals = [
  "Pass the AWS Solutions Architect Associate exam",
  "Build a portfolio of 3 full-stack web apps",
  "Learn machine learning fundamentals and complete a Kaggle competition",
  "Master React and get a frontend developer job",
];

export default function GoalIntake() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [step, setStep] = useState<"input" | "parsing" | "confirm" | "generating">("input");
  const [rawGoal, setRawGoal] = useState("");
  const [parsed, setParsed] = useState<ParsedGoal | null>(null);

  const parseMutation = trpc.goals.parseGoal.useMutation({
    onSuccess: (data) => {
      setParsed(data);
      setStep("confirm");
    },
    onError: (err) => {
      toast.error("Failed to parse goal: " + err.message);
      setStep("input");
    },
  });

  const createMutation = trpc.goals.create.useMutation({
    onSuccess: (data) => {
      toast.success("Learning plan created!");
      navigate(`/goals/${data.goalId}/dashboard`);
    },
    onError: (err) => {
      toast.error("Failed to create plan: " + err.message);
      setStep("confirm");
    },
  });

  const handleParse = () => {
    if (!rawGoal.trim()) return;
    setStep("parsing");
    parseMutation.mutate({ rawGoal: rawGoal.trim() });
  };

  const handleCreate = () => {
    if (!parsed) return;
    setStep("generating");
    createMutation.mutate({
      rawGoal: rawGoal.trim(),
      domain: parsed.domain,
      skillLevel: parsed.skillLevel,
      targetOutcome: parsed.targetOutcome,
      timelineWeeks: parsed.timelineWeeks,
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="text-center">
          <h2 className="font-display text-2xl font-bold mb-3">Sign in to continue</h2>
          <Button onClick={() => startLogin()} className="gradient-primary text-white glow">Sign In</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b border-border/50 glass sticky top-0 z-40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/goals")}>
            <div className="w-7 h-7 rounded-lg gradient-primary flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-semibold tracking-tight">Pathwise</span>
          </div>
          <Button variant="ghost" size="sm" onClick={() => navigate("/goals")}>
            <ArrowLeft className="w-4 h-4 mr-1.5" />
            Back
          </Button>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-2xl">
          <AnimatePresence mode="wait">
            {/* Step 1: Input */}
            {step === "input" && (
              <motion.div
                key="input"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.35 }}
              >
                <div className="text-center mb-10">
                  <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-5 glow">
                    <Brain className="w-8 h-8 text-white" />
                  </div>
                  <h1 className="font-display text-3xl sm:text-4xl font-bold mb-3">
                    What do you want to learn?
                  </h1>
                  <p className="text-muted-foreground text-lg">
                    Describe your goal in your own words. Our AI will build a personalized plan.
                  </p>
                </div>

                <div className="glass rounded-2xl p-6">
                  <Textarea
                    placeholder="e.g. Pass the AWS Solutions Architect Associate exam in 3 months. I have basic cloud knowledge but no AWS experience."
                    value={rawGoal}
                    onChange={(e) => setRawGoal(e.target.value)}
                    className="min-h-[120px] bg-transparent border-border/50 focus:border-primary/50 resize-none text-base leading-relaxed"
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleParse();
                    }}
                  />

                  <div className="mt-4 mb-5">
                    <p className="text-xs text-muted-foreground mb-2">Try an example:</p>
                    <div className="flex flex-wrap gap-2">
                      {exampleGoals.map((eg) => (
                        <button
                          key={eg}
                          onClick={() => setRawGoal(eg)}
                          className="text-xs px-3 py-1.5 rounded-lg bg-secondary/60 hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
                        >
                          {eg}
                        </button>
                      ))}
                    </div>
                  </div>

                  <Button
                    onClick={handleParse}
                    disabled={!rawGoal.trim() || rawGoal.length < 5}
                    className="w-full gradient-primary text-white glow py-6 text-base font-semibold rounded-xl"
                  >
                    Analyze My Goal
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              </motion.div>
            )}

            {/* Step 2: Parsing */}
            {step === "parsing" && (
              <motion.div
                key="parsing"
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.97 }}
                className="text-center py-16"
              >
                <div className="w-20 h-20 rounded-3xl gradient-primary flex items-center justify-center mx-auto mb-6 glow">
                  <Brain className="w-10 h-10 text-white animate-pulse" />
                </div>
                <h2 className="font-display text-2xl font-bold mb-3">Analyzing your goal...</h2>
                <p className="text-muted-foreground">
                  Our AI is parsing your intent, assessing skill level, and estimating a realistic timeline.
                </p>
                <div className="flex items-center justify-center gap-1.5 mt-6">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="w-2 h-2 rounded-full bg-primary animate-bounce"
                      style={{ animationDelay: `${i * 0.15}s` }}
                    />
                  ))}
                </div>
              </motion.div>
            )}

            {/* Step 3: Confirm */}
            {step === "confirm" && parsed && (
              <motion.div
                key="confirm"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.35 }}
              >
                <div className="text-center mb-8">
                  <div className="w-14 h-14 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-7 h-7 text-green-400" />
                  </div>
                  <h2 className="font-display text-2xl sm:text-3xl font-bold mb-2">Goal Analyzed</h2>
                  <p className="text-muted-foreground">Here's what our AI understood about your goal.</p>
                </div>

                <div className="glass rounded-2xl p-6 mb-5 space-y-5">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Your Goal</p>
                    <p className="font-medium text-base">{rawGoal}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-secondary/40 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-1.5">
                        <Target className="w-4 h-4 text-primary" />
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">Domain</p>
                      </div>
                      <p className="font-semibold text-sm">{parsed.domain}</p>
                    </div>
                    <div className="bg-secondary/40 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-1.5">
                        <BarChart className="w-4 h-4 text-primary" />
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">Skill Level</p>
                      </div>
                      <Badge className={`text-xs capitalize ${skillColors[parsed.skillLevel]}`}>
                        {parsed.skillLevel}
                      </Badge>
                    </div>
                    <div className="bg-secondary/40 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-1.5">
                        <Clock className="w-4 h-4 text-primary" />
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">Timeline</p>
                      </div>
                      <p className="font-semibold text-sm">{parsed.timelineWeeks} weeks</p>
                    </div>
                    <div className="bg-secondary/40 rounded-xl p-4 col-span-2">
                      <div className="flex items-center gap-2 mb-1.5">
                        <CheckCircle2 className="w-4 h-4 text-primary" />
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">Target Outcome</p>
                      </div>
                      <p className="font-medium text-sm">{parsed.targetOutcome}</p>
                    </div>
                  </div>
                  <div className="bg-primary/5 border border-primary/10 rounded-xl p-4">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5">AI Assessment</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{parsed.reasoning}</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setStep("input")}
                    className="flex-1 py-6 rounded-xl"
                  >
                    <ArrowLeft className="mr-2 w-4 h-4" />
                    Edit Goal
                  </Button>
                  <Button
                    onClick={handleCreate}
                    className="flex-[2] gradient-primary text-white glow py-6 text-base font-semibold rounded-xl"
                  >
                    Generate My Learning Plan
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              </motion.div>
            )}

            {/* Step 4: Generating */}
            {step === "generating" && (
              <motion.div
                key="generating"
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-16"
              >
                <div className="w-20 h-20 rounded-3xl gradient-primary flex items-center justify-center mx-auto mb-6 glow">
                  <Loader2 className="w-10 h-10 text-white animate-spin" />
                </div>
                <h2 className="font-display text-2xl font-bold mb-3">Building your learning plan...</h2>
                <p className="text-muted-foreground max-w-sm mx-auto">
                  Our AI is crafting a personalized, week-by-week milestone plan tailored to your goal and skill level.
                </p>
                <div className="mt-8 space-y-2 max-w-xs mx-auto text-left">
                  {["Structuring milestones", "Creating weekly tasks", "Setting up progress tracking", "Preparing smart nudges"].map(
                    (item, i) => (
                      <motion.div
                        key={item}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.4 }}
                        className="flex items-center gap-2 text-sm text-muted-foreground"
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                        {item}
                      </motion.div>
                    )
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

