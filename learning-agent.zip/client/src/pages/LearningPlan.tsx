import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation, useParams } from "wouter";
import { toast } from "sonner";
import {
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  Circle,
  Clock,
  BookOpen,
  Video,
  FileText,
  Code2,
  Wrench,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Brain,
  Trophy,
  Loader2,
  BarChart3,
  RefreshCw,
} from "lucide-react";

const taskTypeConfig = {
  video: { icon: Video, color: "text-red-400", bg: "bg-red-500/10", label: "Video" },
  article: { icon: FileText, color: "text-blue-400", bg: "bg-blue-500/10", label: "Article" },
  practice: { icon: Code2, color: "text-green-400", bg: "bg-green-500/10", label: "Practice" },
  quiz: { icon: Brain, color: "text-purple-400", bg: "bg-purple-500/10", label: "Quiz" },
  project: { icon: Wrench, color: "text-orange-400", bg: "bg-orange-500/10", label: "Project" },
  remedial: { icon: AlertTriangle, color: "text-yellow-400", bg: "bg-yellow-500/10", label: "Remedial" },
};

const milestoneStatusConfig = {
  pending: { color: "text-muted-foreground", bg: "bg-secondary", label: "Pending" },
  in_progress: { color: "text-primary", bg: "bg-primary/10", label: "In Progress" },
  completed: { color: "text-green-400", bg: "bg-green-500/10", label: "Completed" },
  delayed: { color: "text-yellow-400", bg: "bg-yellow-500/10", label: "Delayed" },
};

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

function QuizModal({
  open,
  onClose,
  milestoneId,
  goalId,
  milestoneTitle,
}: {
  open: boolean;
  onClose: () => void;
  milestoneId: number;
  goalId: number;
  milestoneTitle: string;
}) {
  const utils = trpc.useUtils();
  const [quizState, setQuizState] = useState<"idle" | "loading" | "taking" | "results">("idle");
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [answers, setAnswers] = useState<number[]>([]);
  const [results, setResults] = useState<{
    score: number;
    passed: boolean;
    results: { questionId: number; selected: number; correct: boolean; explanation: string }[];
  } | null>(null);
  const [feedbackApplied, setFeedbackApplied] = useState(false);

  const generateMutation = trpc.quizzes.generate.useMutation({
    onSuccess: (data) => {
      setQuestions(data.questions as QuizQuestion[]);
      setAnswers(new Array(data.questions.length).fill(-1));
      setQuizState("taking");
    },
    onError: (err) => {
      toast.error("Failed to generate quiz: " + err.message);
      setQuizState("idle");
    },
  });

  const submitMutation = trpc.quizzes.submit.useMutation({
    onSuccess: (data) => {
      setResults(data);
      setQuizState("results");
      utils.goals.get.invalidate({ goalId });
      utils.goals.dashboard.invalidate({ goalId });
    },
    onError: (err) => {
      toast.error("Failed to submit: " + err.message);
    },
  });

  const adaptMutation = trpc.goals.adaptPlan.useMutation({
    onSuccess: (data) => {
      setFeedbackApplied(true);
      toast.success(`Plan adapted: ${data.addedTasks} remedial tasks added`);
      utils.goals.get.invalidate({ goalId });
      utils.goals.dashboard.invalidate({ goalId });
    },
    onError: (err) => toast.error("Adaptation failed: " + err.message),
  });

  const handleStart = () => {
    setQuizState("loading");
    generateMutation.mutate({ milestoneId, goalId });
  };

  const handleSubmit = () => {
    if (answers.some((a) => a === -1)) {
      toast.error("Please answer all questions before submitting.");
      return;
    }
    submitMutation.mutate({ milestoneId, goalId, questions, answers });
  };

  const handleAdaptPlan = () => {
    adaptMutation.mutate({ goalId, milestoneId, reason: "quiz_failed" });
  };

  const handleClose = () => {
    setQuizState("idle");
    setQuestions([]);
    setAnswers([]);
    setResults(null);
    setFeedbackApplied(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto bg-card border-border/50">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display text-xl">
            <Brain className="w-5 h-5 text-primary" />
            Milestone Quiz
          </DialogTitle>
          <p className="text-sm text-muted-foreground">{milestoneTitle}</p>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {quizState === "idle" && (
            <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-8">
              <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4 glow">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Ready to test your knowledge?</h3>
              <p className="text-muted-foreground text-sm mb-6 max-w-sm mx-auto">
                Take a 5-question quiz on this milestone. A score below 70% will automatically adapt your learning plan.
              </p>
              <Button onClick={handleStart} className="gradient-primary text-white glow px-8">
                Start Quiz
              </Button>
            </motion.div>
          )}

          {quizState === "loading" && (
            <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-8">
              <Loader2 className="w-10 h-10 text-primary animate-spin mx-auto mb-4" />
              <p className="text-muted-foreground">Generating quiz questions...</p>
            </motion.div>
          )}

          {quizState === "taking" && (
            <motion.div key="taking" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
              {questions.map((q, qi) => (
                <div key={q.id} className="space-y-3">
                  <p className="font-medium text-sm leading-relaxed">
                    <span className="text-primary font-bold mr-2">{qi + 1}.</span>
                    {q.question}
                  </p>
                  <div className="space-y-2">
                    {q.options.map((opt, oi) => (
                      <button
                        key={oi}
                        onClick={() => {
                          const newAnswers = [...answers];
                          newAnswers[qi] = oi;
                          setAnswers(newAnswers);
                        }}
                        className={`w-full text-left p-3 rounded-xl text-sm transition-all duration-150 ${
                          answers[qi] === oi
                            ? "bg-primary/15 border border-primary/40 text-foreground"
                            : "bg-secondary/40 border border-border/30 text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
                        }`}
                      >
                        <span className="font-medium mr-2">{String.fromCharCode(65 + oi)}.</span>
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              <div className="flex items-center justify-between pt-2">
                <p className="text-xs text-muted-foreground">
                  {answers.filter((a) => a !== -1).length}/{questions.length} answered
                </p>
                <Button
                  onClick={handleSubmit}
                  disabled={submitMutation.isPending}
                  className="gradient-primary text-white glow"
                >
                  {submitMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Submit Quiz
                </Button>
              </div>
            </motion.div>
          )}

          {quizState === "results" && results && (
            <motion.div key="results" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
              {/* Score */}
              <div className={`rounded-2xl p-6 text-center ${results.passed ? "bg-green-500/10 border border-green-500/20" : "bg-red-500/10 border border-red-500/20"}`}>
                <div className={`text-5xl font-bold mb-1 ${results.passed ? "text-green-400" : "text-red-400"}`}>
                  {results.score}%
                </div>
                <div className="flex items-center justify-center gap-2">
                  {results.passed ? (
                    <><Trophy className="w-5 h-5 text-green-400" /><span className="text-green-400 font-semibold">Passed!</span></>
                  ) : (
                    <><AlertTriangle className="w-5 h-5 text-red-400" /><span className="text-red-400 font-semibold">Needs Improvement</span></>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  {results.passed ? "Great work! You've mastered this milestone." : "Don't worry — we'll adapt your plan to help you improve."}
                </p>
              </div>

              {/* Adapt Plan Button */}
              {!results.passed && !feedbackApplied && (
                <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <RefreshCw className="w-5 h-5 text-yellow-400 shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="font-medium text-sm mb-1">Adapt My Learning Plan</p>
                      <p className="text-xs text-muted-foreground mb-3">
                        Add remedial tasks and review content to strengthen your understanding before moving on.
                      </p>
                      <Button
                        onClick={handleAdaptPlan}
                        disabled={adaptMutation.isPending}
                        size="sm"
                        className="bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 border border-yellow-500/30"
                      >
                        {adaptMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin mr-1.5" /> : <RefreshCw className="w-3 h-3 mr-1.5" />}
                        Apply Feedback to Plan
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              {feedbackApplied && (
                <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                  <p className="text-sm text-green-400 font-medium">Plan adapted! Remedial tasks have been added.</p>
                </div>
              )}

              {/* Question Review */}
              <div className="space-y-3">
                <p className="font-semibold text-sm">Question Review</p>
                {results.results.map((r, i) => (
                  <div key={r.questionId} className={`rounded-xl p-3 ${r.correct ? "bg-green-500/5 border border-green-500/15" : "bg-red-500/5 border border-red-500/15"}`}>
                    <div className="flex items-start gap-2">
                      {r.correct ? <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />}
                      <div>
                        <p className="text-sm font-medium mb-1">{questions[i]?.question}</p>
                        <p className="text-xs text-muted-foreground">{r.explanation}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <Button onClick={handleClose} variant="outline" className="w-full">
                Close
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}

function TaskItem({
  task,
  goalId,
  onUpdate,
}: {
  task: {
    id: number;
    title: string;
    description: string | null;
    type: "video" | "article" | "practice" | "quiz" | "project" | "remedial";
    status: "pending" | "in_progress" | "completed";
    estimatedMinutes: number | null;
    actualMinutes: number | null;
    isRemedial: boolean | null;
    completedAt: Date | null;
  };
  goalId: number;
  onUpdate: () => void;
}) {
  const [timeInput, setTimeInput] = useState("");
  const [showTimeInput, setShowTimeInput] = useState(false);
  const cfg = taskTypeConfig[task.type];
  const utils = trpc.useUtils();

  const completeMutation = trpc.tasks.complete.useMutation({
    onSuccess: () => {
      onUpdate();
      setShowTimeInput(false);
      setTimeInput("");
      toast.success("Task completed!");
    },
    onError: (err) => toast.error(err.message),
  });

  const uncompleteMutation = trpc.tasks.uncomplete.useMutation({
    onSuccess: () => {
      onUpdate();
      toast.success("Task marked as incomplete.");
    },
    onError: (err) => toast.error(err.message),
  });

  const handleComplete = () => {
    if (showTimeInput) {
      completeMutation.mutate({
        taskId: task.id,
        goalId,
        actualMinutes: parseInt(timeInput) || task.estimatedMinutes || 30,
      });
    } else {
      setShowTimeInput(true);
    }
  };

  const isCompleted = task.status === "completed";

  return (
    <div className={`flex items-start gap-3 p-3 rounded-xl transition-all duration-200 ${isCompleted ? "opacity-60" : "hover:bg-secondary/30"} ${task.isRemedial ? "border border-yellow-500/20 bg-yellow-500/5" : ""}`}>
      <button
        onClick={() => isCompleted ? uncompleteMutation.mutate({ taskId: task.id, goalId }) : handleComplete()}
        className="mt-0.5 shrink-0"
        disabled={completeMutation.isPending || uncompleteMutation.isPending}
      >
        {isCompleted ? (
          <CheckCircle2 className="w-5 h-5 text-green-400" />
        ) : (
          <Circle className="w-5 h-5 text-muted-foreground hover:text-primary transition-colors" />
        )}
      </button>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className={`text-sm font-medium ${isCompleted ? "line-through text-muted-foreground" : ""}`}>
            {task.title}
          </p>
          {task.isRemedial && (
            <Badge className="text-[10px] bg-yellow-500/10 text-yellow-400 border-yellow-500/20 px-1.5 py-0">
              Remedial
            </Badge>
          )}
        </div>
        {task.description && (
          <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{task.description}</p>
        )}
        <div className="flex items-center gap-3 mt-1.5">
          <div className={`flex items-center gap-1 ${cfg.bg} rounded-md px-1.5 py-0.5`}>
            <cfg.icon className={`w-3 h-3 ${cfg.color}`} />
            <span className={`text-[10px] font-medium ${cfg.color}`}>{cfg.label}</span>
          </div>
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {isCompleted ? `${task.actualMinutes}` : `~${task.estimatedMinutes}`} min
          </span>
        </div>
        {showTimeInput && !isCompleted && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="flex items-center gap-2 mt-2"
          >
            <Input
              type="number"
              placeholder={`Time spent (est. ${task.estimatedMinutes} min)`}
              value={timeInput}
              onChange={(e) => setTimeInput(e.target.value)}
              className="h-8 text-xs w-48 bg-secondary/40"
              onKeyDown={(e) => e.key === "Enter" && handleComplete()}
            />
            <Button size="sm" onClick={handleComplete} disabled={completeMutation.isPending} className="h-8 text-xs gradient-primary text-white">
              {completeMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : "Done"}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setShowTimeInput(false)} className="h-8 text-xs">
              Cancel
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default function LearningPlan() {
  const params = useParams<{ goalId: string }>();
  const goalId = parseInt(params.goalId);
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [expandedMilestones, setExpandedMilestones] = useState<Set<number>>(new Set([0]));
  const [quizModal, setQuizModal] = useState<{ open: boolean; milestoneId: number; title: string } | null>(null);
  const utils = trpc.useUtils();

  const { data: goalData, isLoading } = trpc.goals.get.useQuery(
    { goalId },
    { enabled: isAuthenticated && !isNaN(goalId) }
  );

  const toggleMilestone = (idx: number) => {
    setExpandedMilestones((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const handleUpdate = () => {
    utils.goals.get.invalidate({ goalId });
    utils.goals.dashboard.invalidate({ goalId });
  };

  if (!isAuthenticated) {
    return <div className="min-h-screen bg-background flex items-center justify-center"><p className="text-muted-foreground">Please sign in.</p></div>;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="border-b border-border/50 h-16" />
        <div className="container py-8 space-y-4">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
        </div>
      </div>
    );
  }

  const goal = goalData?.goal;
  const milestones = goalData?.milestones ?? [];

  if (!goal) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Goal not found.</p>
          <Button onClick={() => navigate("/goals")}>Back to Goals</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/50 glass sticky top-0 z-40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(`/goals/${goalId}/dashboard`)} className="text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg gradient-primary flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold tracking-tight hidden sm:block">Pathwise</span>
            </div>
          </div>
          <Button
            onClick={() => navigate(`/goals/${goalId}/dashboard`)}
            variant="outline"
            size="sm"
          >
            <BarChart3 className="w-4 h-4 mr-1.5" />
            Dashboard
          </Button>
        </div>
      </div>

      <div className="container py-8">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{goal.domain}</p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold mb-2">{goal.rawGoal}</h1>
          <p className="text-muted-foreground text-sm">{milestones.length} milestones · {goal.timelineWeeks} weeks</p>
        </motion.div>

        <div className="space-y-4">
          {milestones.map((milestone, idx) => {
            const isExpanded = expandedMilestones.has(idx);
            const completedTasks = milestone.tasks.filter((t) => t.status === "completed").length;
            const totalTasks = milestone.tasks.length;
            const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
            const cfg = milestoneStatusConfig[milestone.status];

            return (
              <motion.div
                key={milestone.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="glass rounded-2xl overflow-hidden"
              >
                {/* Milestone Header */}
                <button
                  onClick={() => toggleMilestone(idx)}
                  className="w-full flex items-center gap-4 p-5 text-left hover:bg-secondary/20 transition-colors"
                >
                  <div className={`w-10 h-10 rounded-xl ${cfg.bg} flex items-center justify-center shrink-0`}>
                    <span className={`text-sm font-bold ${cfg.color}`}>{milestone.weekNumber}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-semibold text-sm">{milestone.title}</h3>
                      <Badge className={`text-[10px] ${cfg.bg} ${cfg.color} border-border/30`}>
                        {cfg.label}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 max-w-[200px]">
                        <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${progress}%`,
                              background: progress === 100 ? "oklch(0.72 0.19 145)" : "oklch(0.72 0.19 265)",
                            }}
                          />
                        </div>
                      </div>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {completedTasks}/{totalTasks} tasks
                      </span>
                    </div>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
                  )}
                </button>

                {/* Expanded Content */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="overflow-hidden"
                    >
                      <div className="px-5 pb-5 border-t border-border/30">
                        {milestone.description && (
                          <p className="text-sm text-muted-foreground py-3 leading-relaxed">
                            {milestone.description}
                          </p>
                        )}
                        <div className="space-y-1">
                          {milestone.tasks.map((task) => (
                            <TaskItem
                              key={task.id}
                              task={task}
                              goalId={goalId}
                              onUpdate={handleUpdate}
                            />
                          ))}
                        </div>
                        {/* Quiz Button */}
                        <div className="mt-4 pt-4 border-t border-border/30">
                          <Button
                            onClick={() =>
                              setQuizModal({ open: true, milestoneId: milestone.id, title: milestone.title })
                            }
                            variant="outline"
                            size="sm"
                            className="w-full border-primary/20 text-primary hover:bg-primary/10"
                          >
                            <Brain className="w-4 h-4 mr-2" />
                            Take Milestone Quiz
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>

      {quizModal && (
        <QuizModal
          open={quizModal.open}
          onClose={() => setQuizModal(null)}
          milestoneId={quizModal.milestoneId}
          goalId={goalId}
          milestoneTitle={quizModal.title}
        />
      )}
    </div>
  );
}

