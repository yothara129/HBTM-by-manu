import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import { useLocation, useParams } from "wouter";
import { toast } from "sonner";
import {
  Sparkles,
  ArrowLeft,
  Flame,
  Target,
  Clock,
  CheckCircle2,
  Bell,
  BellDot,
  BookOpen,
  BarChart3,
  Calendar,
  AlertCircle,
  X,
  ChevronRight,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { formatDistanceToNow } from "date-fns";

function NudgesPanel({
  open,
  onClose,
  goalId,
}: {
  open: boolean;
  onClose: () => void;
  goalId: number;
}) {
  const utils = trpc.useUtils();
  const { data: nudges, isLoading } = trpc.nudges.list.useQuery();
  const markAllRead = trpc.nudges.markAllRead.useMutation({
    onSuccess: () => utils.nudges.list.invalidate(),
  });
  const markRead = trpc.nudges.markRead.useMutation({
    onSuccess: () => utils.nudges.list.invalidate(),
  });

  const goalNudges = nudges?.filter((n) => n.goalId === goalId) ?? [];
  const unread = goalNudges.filter((n) => !n.isRead).length;

  const nudgeTypeConfig = {
    inactivity: { color: "text-yellow-400", bg: "bg-yellow-500/10", label: "Inactivity Alert" },
    quiz_failure: { color: "text-red-400", bg: "bg-red-500/10", label: "Quiz Feedback" },
    milestone_complete: { color: "text-green-400", bg: "bg-green-500/10", label: "Milestone Complete" },
    encouragement: { color: "text-primary", bg: "bg-primary/10", label: "Encouragement" },
  };

  if (!open) return null;

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="fixed right-4 top-20 w-96 glass rounded-2xl shadow-2xl z-50 overflow-hidden"
    >
      <div className="flex items-center justify-between p-4 border-b border-border/50">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-primary" />
          <span className="font-semibold text-sm">Smart Nudges</span>
          {unread > 0 && (
            <Badge className="bg-primary/10 text-primary border-primary/20 text-xs px-1.5 py-0.5">
              {unread}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          {unread > 0 && (
            <button
              onClick={() => markAllRead.mutate()}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              Mark all read
            </button>
          )}
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
      <div className="max-h-[480px] overflow-y-auto">
        {isLoading ? (
          <div className="p-4 space-y-3">
            {[1, 2].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
          </div>
        ) : goalNudges.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground text-sm">
            <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
            No nudges yet. Keep learning!
          </div>
        ) : (
          <div className="p-3 space-y-2">
            {goalNudges.map((nudge) => {
              const cfg = nudgeTypeConfig[nudge.type];
              return (
                <div
                  key={nudge.id}
                  className={`rounded-xl p-3 ${cfg.bg} border border-border/30 ${!nudge.isRead ? "ring-1 ring-primary/20" : "opacity-70"}`}
                  onClick={() => !nudge.isRead && markRead.mutate({ nudgeId: nudge.id })}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-xs font-medium ${cfg.color}`}>{cfg.label}</span>
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(nudge.createdAt), { addSuffix: true })}
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed">{nudge.message}</p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </motion.div>
  );
}

export default function Dashboard() {
  const params = useParams<{ goalId: string }>();
  const goalId = parseInt(params.goalId);
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [nudgesOpen, setNudgesOpen] = useState(false);
  const utils = trpc.useUtils();

  const { data: goalData, isLoading: goalLoading } = trpc.goals.get.useQuery(
    { goalId },
    { enabled: isAuthenticated && !isNaN(goalId) }
  );
  const { data: stats, isLoading: statsLoading } = trpc.goals.dashboard.useQuery(
    { goalId },
    { enabled: isAuthenticated && !isNaN(goalId), refetchInterval: 10000 }
  );
  const { data: activityData } = trpc.tasks.activityLog.useQuery(
    { goalId, days: 14 },
    { enabled: isAuthenticated && !isNaN(goalId) }
  );
  const { data: nudges } = trpc.nudges.list.useQuery(undefined, { enabled: isAuthenticated });

  const checkNudges = trpc.nudges.checkAndGenerate.useMutation({
    onSuccess: (data) => {
      if (data.generated > 0) {
        utils.nudges.list.invalidate();
        setNudgesOpen(true);
      }
    },
  });

  // Check nudges on mount
  useState(() => {
    if (isAuthenticated) {
      checkNudges.mutate();
    }
  });

  const unreadNudges = nudges?.filter((n) => n.goalId === goalId && !n.isRead).length ?? 0;

  const goal = goalData?.goal;
  const milestones = goalData?.milestones ?? [];

  // Build activity chart data (last 14 days)
  const chartData = (() => {
    const days: { day: string; actual: number; planned: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const log = activityData?.find((l) => l.date === dateStr);
      days.push({
        day: d.toLocaleDateString("en", { weekday: "short" }),
        actual: log?.minutesSpent ?? 0,
        planned: 45,
      });
    }
    return days;
  })();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Please sign in to view your dashboard.</p>
      </div>
    );
  }

  if (goalLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="border-b border-border/50 h-16" />
        <div className="container py-8 space-y-6">
          <Skeleton className="h-8 w-64" />
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-32 rounded-2xl" />)}
          </div>
          <Skeleton className="h-64 rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!goal) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Goal not found.</p>
          <Button onClick={() => navigate("/goals")} className="mt-4">Back to Goals</Button>
        </div>
      </div>
    );
  }

  const completedMilestones = milestones.filter((m) => m.status === "completed").length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/50 glass sticky top-0 z-40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/goals")} className="text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg gradient-primary flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold tracking-tight hidden sm:block">Pathwise</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(`/goals/${goalId}/plan`)}
              className="hidden sm:flex"
            >
              <BookOpen className="w-4 h-4 mr-1.5" />
              Learning Plan
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setNudgesOpen(!nudgesOpen)}
              className="relative"
            >
              {unreadNudges > 0 ? (
                <BellDot className="w-5 h-5 text-primary" />
              ) : (
                <Bell className="w-5 h-5" />
              )}
              {unreadNudges > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-primary rounded-full text-[10px] text-primary-foreground flex items-center justify-center font-bold">
                  {unreadNudges}
                </span>
              )}
            </Button>
          </div>
        </div>
      </div>

      <NudgesPanel open={nudgesOpen} onClose={() => setNudgesOpen(false)} goalId={goalId} />

      <div className="container py-8">
        {/* Goal Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{goal.domain}</p>
              <h1 className="font-display text-2xl sm:text-3xl font-bold leading-tight mb-2">
                {goal.rawGoal}
              </h1>
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="bg-primary/10 text-primary border-primary/20 text-xs capitalize">
                  {goal.skillLevel}
                </Badge>
                <Badge className="bg-secondary text-muted-foreground border-border/50 text-xs">
                  <Clock className="w-3 h-3 mr-1" />
                  {goal.timelineWeeks} weeks
                </Badge>
                <Badge className="bg-secondary text-muted-foreground border-border/50 text-xs">
                  <Target className="w-3 h-3 mr-1" />
                  {completedMilestones}/{milestones.length} milestones
                </Badge>
              </div>
            </div>
            <Button
              onClick={() => navigate(`/goals/${goalId}/plan`)}
              className="gradient-primary text-white glow-sm shrink-0 hidden sm:flex"
            >
              View Plan
              <ChevronRight className="ml-1 w-4 h-4" />
            </Button>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            {
              label: "Completion",
              value: `${stats?.completionPct ?? 0}%`,
              icon: Target,
              color: "text-primary",
              bg: "bg-primary/10",
              sub: `${stats?.completedTasks ?? 0} of ${stats?.totalTasks ?? 0} tasks`,
            },
            {
              label: "Learning Streak",
              value: `${stats?.streak ?? 0}`,
              icon: Flame,
              color: "text-orange-400",
              bg: "bg-orange-500/10",
              sub: stats?.streak === 1 ? "day" : "days",
            },
            {
              label: "Time Spent",
              value: `${Math.round((stats?.totalActualMinutes ?? 0) / 60)}h`,
              icon: Clock,
              color: "text-green-400",
              bg: "bg-green-500/10",
              sub: `of ${Math.round((stats?.totalEstimatedMinutes ?? 0) / 60)}h planned`,
            },
            {
              label: "Milestones",
              value: `${completedMilestones}/${milestones.length}`,
              icon: CheckCircle2,
              color: "text-blue-400",
              bg: "bg-blue-500/10",
              sub: "completed",
            },
          ].map((card, i) => (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07 }}
              className="glass rounded-2xl p-5"
            >
              <div className={`w-9 h-9 rounded-xl ${card.bg} flex items-center justify-center mb-3`}>
                <card.icon className={`w-4.5 h-4.5 ${card.color}`} />
              </div>
              <p className="text-xs text-muted-foreground mb-1">{card.label}</p>
              <p className={`text-2xl font-bold ${card.color}`}>{card.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{card.sub}</p>
            </motion.div>
          ))}
        </div>

        {/* Progress Bar */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass rounded-2xl p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              <span className="font-semibold text-sm">Overall Progress</span>
            </div>
            <span className="text-2xl font-bold text-primary">{stats?.completionPct ?? 0}%</span>
          </div>
          <Progress value={stats?.completionPct ?? 0} className="h-3 rounded-full" />
          <p className="text-xs text-muted-foreground mt-2">
            {stats?.completedTasks ?? 0} tasks completed · {(stats?.totalTasks ?? 0) - (stats?.completedTasks ?? 0)} remaining
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Activity Chart */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="glass rounded-2xl p-6"
          >
            <div className="flex items-center gap-2 mb-5">
              <BarChart3 className="w-4 h-4 text-primary" />
              <span className="font-semibold text-sm">Time Spent vs Planned (last 14 days)</span>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={chartData} barGap={2}>
                <XAxis
                  dataKey="day"
                  tick={{ fontSize: 11, fill: "oklch(0.6 0.02 265)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis hide />
                <Tooltip
                  contentStyle={{
                    background: "oklch(0.14 0.015 265)",
                    border: "1px solid oklch(0.22 0.02 265)",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                  labelStyle={{ color: "oklch(0.96 0.005 265)" }}
                />
                <Bar dataKey="planned" radius={[3, 3, 0, 0]} fill="oklch(0.22 0.02 265)" name="Planned (min)" />
                <Bar dataKey="actual" radius={[3, 3, 0, 0]} name="Actual (min)">
                  {chartData.map((entry, index) => (
                    <Cell
                      key={index}
                      fill={entry.actual >= entry.planned ? "oklch(0.72 0.19 145)" : "oklch(0.72 0.19 265)"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="flex items-center gap-4 mt-2">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-secondary" />
                <span className="text-xs text-muted-foreground">Planned</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm" style={{ background: "oklch(0.72 0.19 265)" }} />
                <span className="text-xs text-muted-foreground">Actual</span>
              </div>
            </div>
          </motion.div>

          {/* Upcoming Tasks */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="glass rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                <span className="font-semibold text-sm">Upcoming Tasks</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate(`/goals/${goalId}/plan`)}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                View all
                <ChevronRight className="ml-1 w-3 h-3" />
              </Button>
            </div>
            {stats?.upcomingTasks && stats.upcomingTasks.length > 0 ? (
              <div className="space-y-2">
                {stats.upcomingTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center gap-3 p-3 rounded-xl bg-secondary/40 hover:bg-secondary/60 transition-colors cursor-pointer"
                    onClick={() => navigate(`/goals/${goalId}/plan`)}
                  >
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <BookOpen className="w-4 h-4 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">{task.title}</p>
                      <p className="text-xs text-muted-foreground">
                        ~{task.estimatedMinutes} min
                        {task.dueDate && (
                          <> · due {formatDistanceToNow(new Date(task.dueDate), { addSuffix: true })}</>
                        )}
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground text-sm">
                <CheckCircle2 className="w-8 h-8 mx-auto mb-2 opacity-30" />
                All caught up! No pending tasks.
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
