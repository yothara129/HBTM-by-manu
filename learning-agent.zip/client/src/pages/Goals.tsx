import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Plus, Target, ArrowRight, Sparkles, BookOpen, CheckCircle2, Pause } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const statusConfig = {
  active: { label: "Active", icon: BookOpen, color: "bg-primary/10 text-primary border-primary/20" },
  completed: { label: "Completed", icon: CheckCircle2, color: "bg-green-500/10 text-green-400 border-green-500/20" },
  paused: { label: "Paused", icon: Pause, color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
};

export default function Goals() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const { data: goals, isLoading } = trpc.goals.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-6 glow">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h2 className="font-display text-2xl font-bold mb-3">Sign in to continue</h2>
          <p className="text-muted-foreground mb-6">Your personalized learning journey awaits.</p>
          <Button onClick={() => startLogin()} className="gradient-primary text-white glow">
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/50 glass sticky top-0 z-40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
            <div className="w-7 h-7 rounded-lg gradient-primary flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-semibold tracking-tight">Pathwise</span>
          </div>
          <Button
            onClick={() => navigate("/goals/new")}
            size="sm"
            className="gradient-primary text-white glow-sm"
          >
            <Plus className="w-4 h-4 mr-1.5" />
            New Goal
          </Button>
        </div>
      </div>

      <div className="container py-10">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <h1 className="font-display text-3xl font-bold mb-1">My Learning Goals</h1>
          <p className="text-muted-foreground mb-8">Track and manage your personalized learning journeys.</p>
        </motion.div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-48 rounded-2xl" />
            ))}
          </div>
        ) : goals && goals.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {goals.map((goal, i) => {
              const cfg = statusConfig[goal.status];
              return (
                <motion.div
                  key={goal.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: i * 0.06 }}
                  className="glass rounded-2xl p-6 hover:border-primary/30 transition-all duration-300 cursor-pointer group"
                  onClick={() => navigate(`/goals/${goal.id}/dashboard`)}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <Target className="w-5 h-5 text-primary" />
                    </div>
                    <Badge className={`text-xs ${cfg.color}`}>
                      <cfg.icon className="w-3 h-3 mr-1" />
                      {cfg.label}
                    </Badge>
                  </div>
                  <h3 className="font-semibold text-base mb-1 line-clamp-2 leading-snug">{goal.rawGoal}</h3>
                  <p className="text-muted-foreground text-sm mb-1">{goal.domain}</p>
                  <p className="text-muted-foreground text-xs mb-4">
                    {goal.timelineWeeks} weeks · {goal.skillLevel}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(goal.createdAt), { addSuffix: true })}
                    </span>
                    <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </motion.div>
              );
            })}

            {/* Add new */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: goals.length * 0.06 }}
              className="glass rounded-2xl p-6 border-dashed border-border/60 hover:border-primary/40 transition-all duration-300 cursor-pointer group flex flex-col items-center justify-center min-h-[180px]"
              onClick={() => navigate("/goals/new")}
            >
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
                <Plus className="w-6 h-6 text-primary" />
              </div>
              <p className="font-medium text-sm">Add New Goal</p>
              <p className="text-muted-foreground text-xs mt-1">Start a new learning journey</p>
            </motion.div>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-24"
          >
            <div className="w-20 h-20 rounded-3xl gradient-primary flex items-center justify-center mx-auto mb-6 glow">
              <Target className="w-10 h-10 text-white" />
            </div>
            <h2 className="font-display text-2xl font-bold mb-3">No goals yet</h2>
            <p className="text-muted-foreground mb-8 max-w-sm mx-auto">
              Set your first learning goal and let AI build a personalized plan for you.
            </p>
            <Button
              onClick={() => navigate("/goals/new")}
              className="gradient-primary text-white glow px-8"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create My First Goal
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
