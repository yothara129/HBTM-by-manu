import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import {
  Brain,
  Target,
  TrendingUp,
  Zap,
  BarChart3,
  ArrowRight,
  Sparkles,
  CheckCircle2,
} from "lucide-react";

const features = [
  {
    icon: Brain,
    title: "AI Goal Parsing",
    description:
      "Describe your goal in plain language. Our AI extracts domain, skill level, target outcome, and a realistic timeline automatically.",
  },
  {
    icon: Target,
    title: "Dynamic Learning Plans",
    description:
      "Week-by-week milestone plans that adapt in real time — accelerating when you're ahead, adding support when you fall behind.",
  },
  {
    icon: BarChart3,
    title: "Progress Dashboard",
    description:
      "Track completion percentage, learning streaks, time spent vs. planned, and upcoming tasks at a glance.",
  },
  {
    icon: Zap,
    title: "Smart Nudges",
    description:
      "Context-aware interventions that reference your specific goal and current state — not generic reminders.",
  },
  {
    icon: TrendingUp,
    title: "Quiz Feedback Loop",
    description:
      "Low quiz scores visibly modify your plan — adding remedial tasks and adjusting timelines automatically.",
  },
  {
    icon: CheckCircle2,
    title: "Task Tracking",
    description:
      "Mark tasks complete, log time spent, and watch your dashboard update in real time.",
  },
];

export default function Home() {
  const { isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();

  const handleCTA = () => {
    if (isAuthenticated) {
      navigate("/goals");
    } else {
      startLogin();
    }
  };

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-lg tracking-tight">Pathwise</span>
          </div>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <Button onClick={() => navigate("/goals")} size="sm" className="gradient-primary text-white glow-sm">
                My Goals
              </Button>
            ) : (
              <Button onClick={() => startLogin()} size="sm" className="gradient-primary text-white glow-sm">
                Sign In
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-32 pb-24 px-4">
        {/* Background glow */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute top-1/3 left-1/4 w-[300px] h-[300px] bg-primary/5 rounded-full blur-2xl" />
        </div>

        <div className="container relative text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20 px-4 py-1.5 text-sm font-medium">
              <Sparkles className="w-3.5 h-3.5 mr-1.5" />
              AI-Powered Learning Agent
            </Badge>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight mb-6"
          >
            From goal to{" "}
            <span className="gradient-text glow-text">mastery</span>,
            <br />
            guided by AI.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Pathwise builds a personalized, adaptive learning plan from your stated goal —
            then acts as your tutor and accountability partner every step of the way.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              onClick={handleCTA}
              disabled={loading}
              size="lg"
              className="gradient-primary text-white glow px-8 py-6 text-base font-semibold rounded-xl transition-all duration-200 active:scale-[0.97]"
            >
              {isAuthenticated ? "Go to My Goals" : "Start Learning Free"}
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 px-4">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4">
              Everything you need to{" "}
              <span className="gradient-text">actually learn</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Not just content recommendations — a complete closed-loop system that reasons about your progress.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="glass rounded-2xl p-6 hover:border-primary/30 transition-all duration-300 group"
              >
                <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-base mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-24 px-4">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative rounded-3xl overflow-hidden glass border border-primary/20 p-12 text-center"
          >
            <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
            <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4 relative">
              Ready to start your learning journey?
            </h2>
            <p className="text-muted-foreground text-lg mb-8 relative">
              Tell us your goal. We'll handle the rest.
            </p>
            <Button
              onClick={handleCTA}
              size="lg"
              className="gradient-primary text-white glow px-8 py-6 text-base font-semibold rounded-xl relative"
            >
              {isAuthenticated ? "Go to My Goals" : "Get Started — It's Free"}
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </motion.div>
        </div>
      </section>

      <footer className="border-t border-border/50 py-8 px-4 text-center text-muted-foreground text-sm">
        <div className="container">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-md gradient-primary flex items-center justify-center">
              <Sparkles className="w-3 h-3 text-white" />
            </div>
            <span className="font-medium text-foreground">Pathwise</span>
          </div>
          <p>AI-Powered Personal Learning Agent · Built for HBTM @ IIIT Pune</p>
        </div>
      </footer>
    </div>
  );
}
